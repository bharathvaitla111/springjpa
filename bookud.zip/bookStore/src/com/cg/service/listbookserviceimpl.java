package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.listbooks;
import com.cg.dao.Listbookdao;

@Service("listbookservice")
public class listbookserviceimpl implements Listbookservice {
	@Autowired
	Listbookdao listbookdao;

	@Override
	public boolean save(listbooks Listbooks) {

		List<listbooks> lb = listbookdao.getAllProducts();

		boolean status = false;
		for (listbooks l : lb) {
			if (l.getTitle().equals(Listbooks.getTitle())) {
				status = true;
			}
		}
		if (status == true)
			return false;
		else {
			listbookdao.save(Listbooks);
			return true;
		}
	}

	

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return listbookdao.delete(id);
	}

	@Override
	public boolean update(listbooks Listbooks) {
		// TODO Auto-generated method stub
		return listbookdao.update(Listbooks);
	}

	@Override
	public listbooks getById(int id) {
		// TODO Auto-generated method stub
		listbooks lb =listbookdao.getById(id);
		return lb;
	}

	@Override
	public List<listbooks> getAllProducts() {
		// TODO Auto-generated method stub
		List<listbooks> lb=listbookdao.getAllProducts();
		return lb;
		}

}
