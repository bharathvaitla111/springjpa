package com.cg.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.beans.listbooks;

public interface Listbookservice {

	boolean save(listbooks Listbooks);
	
	boolean delete(int id);

	boolean update(listbooks Listbooks);

	listbooks getById(int id);
	
	List<listbooks> getAllProducts();

}
