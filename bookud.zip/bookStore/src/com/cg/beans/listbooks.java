package com.cg.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;


@Entity
@Component
public class listbooks implements Serializable{

	@Id
	@GeneratedValue(generator = "bb", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "bb", sequenceName = "bb", initialValue = 100, allocationSize = 1)
	private int id;
	private String Title;
	private String Author;
	private String Category;
	private Float price;
	
	private Date LastUpdated;
	
	public listbooks() {
		// TODO Auto-generated constructor stub
	}

	public listbooks(int id, String title, String author, String category, Float price, Date lastUpdated) {
		super();
		this.id = id;
		Title = title;
		Author = author;
		Category = category;
		this.price = price;
		LastUpdated = lastUpdated;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Date getLastUpdated() {
		return LastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		LastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "listbooks [id=" + id + ", Title=" + Title + ", Author=" + Author + ", Category=" + Category + ", price="
				+ price + ", LastUpdated=" + LastUpdated + "]";
	}

}