package com.cg.dao;

import java.util.List;

import com.cg.beans.listbooks;

public interface Listbookdao {
boolean save(listbooks Listbooks);
	
	boolean delete(int id);

	boolean update(listbooks Listbooks);

	listbooks getById(int id);
	
	List<listbooks> getAllProducts();
}
