package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.listbooks;
@Repository("listbookdao")
public class listbooksdaoimpl implements Listbookdao {
	@PersistenceContext
	EntityManager entitymanager;
@Transactional
	@Override
	public boolean save(listbooks Listbooks) {
	entitymanager.persist(Listbooks);
	return true;
	}

	@Override
	public boolean delete(int id) {
		listbooks p=entitymanager.find(listbooks.class, id);
		entitymanager.remove(p);
				return true;
	}

	@Override
	public boolean update(listbooks Listbooks) {
		entitymanager.merge(Listbooks);
		return true;
	}

	@Override
	public listbooks getById(int id) {
listbooks p=entitymanager.find(listbooks.class, id);
		
		return p;	
	}

	@Override
	public List<listbooks> getAllProducts() {
		Query q=entitymanager.createQuery("from listbooks");
		
		List<listbooks> list=q.getResultList();
		System.out.println(list);
				return list;
	}

}
