package com.cg.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.listbooks;
import com.cg.service.Listbookservice;

@Controller
public class BookStoreController {
	
	@Autowired
	Listbookservice listbookservice;

	
	@RequestMapping("/booklist")
	public ModelAndView viewallBooks(HttpServletRequest request) {
		List<listbooks> booklist = listbookservice.getAllProducts();
		   ModelAndView view = new ModelAndView();
		   HttpSession session = request.getSession();
		   session.setAttribute("list", booklist);
view.setViewName("listbook");
return view;
	}
	
	@RequestMapping("/addbook")
	public String showpersonform(Model m) {
		listbooks p = new listbooks();
		
		m.addAttribute("command", p);
		return "addbook";

	}
	
	   
	   @RequestMapping("/save")
		public ModelAndView addBook(HttpServletRequest request,@ModelAttribute("listbook") @Valid listbooks person,BindingResult bindingResult) {
		
		   ModelAndView view = new ModelAndView();
		   
		  if(bindingResult.hasErrors()) {
		  System.out.println("ui details not correct");
		  view.setViewName("addbook");
		  return view;
		  }
		 
			Date date = new Date();
			person.setLastUpdated(date);
			listbookservice.save(person);
			
			List<listbooks> listbooks = listbookservice.getAllProducts();
			view.addObject("plist",listbooks);
			HttpSession session = request.getSession();
			session.setAttribute("list", listbooks);
			view.setViewName("listbook");
			return view;

}
}
