package com.cg.controller;



import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.mypaymentapp.service.WalletService;

@Controller
public class MyController {
	
	@Autowired
	WalletService walletService;
	
	@RequestMapping("/addform")
	public String addform() {
		return "addform";
	}
	
	@RequestMapping("/loginlink")
	public String loginlink() {
		return "myhome";
	}
	
	@RequestMapping("/save")
	public String addProduct(HttpServletRequest request) {
		String name=request.getParameter("name");
		String mobileno=request.getParameter("mobileno");
		BigDecimal amount=new BigDecimal(request.getParameter("balance"));
		walletService.createAccount(name, mobileno, amount);
		return "redirect:/myhome";
	}
	
	@RequestMapping("/withdrawform")
	public String custlist() {
		return "withdrawform";
		/*walletService.withdrawAmount(mobileNo, amount)*/
	}
	//@RequestMapping("/withdraw")
	//public String 
	
	
	
	
	
}
