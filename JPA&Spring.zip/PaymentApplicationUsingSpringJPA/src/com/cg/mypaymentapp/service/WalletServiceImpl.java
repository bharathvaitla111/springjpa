package com.cg.mypaymentapp.service;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;
@Service("walletService")
public class WalletServiceImpl implements WalletService {
	@Autowired
	WalletRepo walletRepo;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		walletRepo.save(c);
		return c;
	}

	@Override
	public Customer showBalance(String mobileno) {
		if (walletRepo.findOne(mobileno) != null) {
			System.out.println("Customer Balance:= " + walletRepo.findOne(mobileno).getWallet().getBalance());
			return walletRepo.findOne(mobileno);
		} else {
			return null;
		}
	}


	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		try {
			if (amount.compareTo(walletRepo.findOne(sourceMobileNo).getWallet().getBalance()) > 0) {
				throw new InsufficientBalanceException("Balance in your account is less to transfer");
			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		if ((walletRepo.findOne(targetMobileNo) != null)
				&& (amount.compareTo(walletRepo.findOne(sourceMobileNo).getWallet().getBalance()) <= 0)) {
			
			BigDecimal bd1 = walletRepo.findOne(targetMobileNo).getWallet().getBalance().add(amount);
			BigDecimal bd2 = walletRepo.findOne(sourceMobileNo).getWallet().getBalance().subtract(amount);
			Wallet w1=walletRepo.findOne(sourceMobileNo).getWallet();
			w1.setBalance(bd2);
			walletRepo.Update(w1);
			Wallet w2=walletRepo.findOne(targetMobileNo).getWallet();
			w2.setBalance(bd1);
			walletRepo.Update(w2);
			System.out.println("funds transferred to " + targetMobileNo + " from " + sourceMobileNo);
			return walletRepo.findOne(targetMobileNo);
		} else {
			System.out.println("no account available with " + targetMobileNo);
			return null;
		}
	}
	
	
	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (walletRepo.findOne(mobileNo) != null) {
			BigDecimal bd = walletRepo.findOne(mobileNo).getWallet().getBalance().add(amount);
			Wallet w1=walletRepo.findOne(mobileNo).getWallet();
			w1.setBalance(bd);
			walletRepo.Update(w1);
			return walletRepo.findOne(mobileNo);
		}
		return null;
	}
	
	
	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		try {
			if (amount.compareTo(walletRepo.findOne(mobileNo).getWallet().getBalance()) > 0) {
				throw new InsufficientBalanceException("Balance in your account is less to withdraw");
			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		if (walletRepo.findOne(mobileNo) != null && (amount.compareTo(walletRepo.findOne(mobileNo).getWallet().getBalance()) <= 0)) {
			BigDecimal bd1 = walletRepo.findOne(mobileNo).getWallet().getBalance().subtract(amount);
			Wallet w=walletRepo.findOne(mobileNo).getWallet();
			w.setBalance(bd1);
			System.out.println("amount withdrawn from " + mobileNo + " is: " + amount);
			walletRepo.Update(w);
			return walletRepo.findOne(mobileNo);
		}
		return null;
	}

}
