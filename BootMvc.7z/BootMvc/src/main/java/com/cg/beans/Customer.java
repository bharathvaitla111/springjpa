package com.cg.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;

@Entity
@Table(name="bootcustomer")
@Component
public class Customer {
	@Id
	@GeneratedValue(generator="bb",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="bb" ,sequenceName="bb",
	initialValue=100,allocationSize=1)
	private int custid;
	@NotBlank(message="username should not be empty")
	private String username;
	@NotBlank(message="lastname should not be empty")
	private String lastname;
	@NotBlank(message="password should not be empty")
	@Pattern(regexp="^[A-Za-z0-9]+$",message="password should be aplha numeric")
	private String password;
	@NotBlank(message="Email should not be empty")
	@Email(message="Invalid email id")
	private String email;
	@NotNull(message="Must provide phone no")
	private Long phone;
	private String role;
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", username=" + username + ", lastname=" + lastname + ", password="
				+ password + ", email=" + email + ", phone=" + phone + ", role=" + role + "]";
	}
	
}




