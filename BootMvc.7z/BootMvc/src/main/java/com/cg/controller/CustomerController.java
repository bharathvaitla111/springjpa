package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.beans.Customer;
import com.cg.dao.CustomerRepository;

@Controller
public class CustomerController {
	@Autowired
	Customer customer;
	@Autowired
	CustomerRepository customerRepository;
	
	@RequestMapping("/")
	public String loadindex() {
		return "index";
	}
	
	@GetMapping(value="/loginlink")
	public String loginlink(ModelMap map) {
		map.addAttribute(customer);
		return "login";
	}
	
	@GetMapping(value="/registerlink")
	public String registerlink(ModelMap map) {
		map.addAttribute(customer);
		return "register";
	}
	@PostMapping(value="login")
	public String validate(@Valid Customer customer,BindingResult br,
			HttpServletRequest request) {
		boolean status=false;
		HttpSession session=request.getSession();
		List<Customer> custlist=customerRepository.findAll();
		for (Customer c : custlist) {
			if(c.getUsername().equals(customer.getUsername()) 
					&& c.getPassword().equals(customer.getPassword())) {
	session.setAttribute("customer", c);
				status=true;
				break;
				}}
		if(br.hasErrors()) {
			return "login";
		}else { if(status) {
				return "customerhome";
			}else {
			session.setAttribute("status", "Invalid username/password");
				return "login";
			}
		}
	}
	
	@PostMapping(value="register")
	public String validate(@Valid Customer customer,BindingResult br) {
		customer.setRole("customer");
		if(br.hasErrors()) {
			return "register";
		}else {
			customerRepository.save(customer);
			return "login";
		}
	}
}
