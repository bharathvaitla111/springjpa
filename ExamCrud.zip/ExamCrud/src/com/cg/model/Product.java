package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ss")
	@SequenceGenerator(name = "ss", sequenceName = "ss", initialValue =100, allocationSize = 1)
	private int pid;
	private String pname;
	private String decription;
	private double price;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	
	public Product(int pid, String pname, String decription, double price) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.decription = decription;
		this.price = price;
	}

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDecription() {
		return decription;
	}
	public void setDecription(String decription) {
		this.decription = decription;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", decription=" + decription + ", price=" + price + "]";
	}
	
}
