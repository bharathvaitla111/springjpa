package com.cg.bookstore.service;

import java.util.List;

import com.cg.bookstore.beans.Customer_Information;

public interface CustomerService {

	

	public boolean createcustomer(Customer_Information customer);

	public List<Customer_Information> getAllCustomers();
	
	public Customer_Information getCustomer_Information(int id);

	public void editCustomer(Customer_Information customer);

	public void deleteCustomer(int id);
	
	
	
}
