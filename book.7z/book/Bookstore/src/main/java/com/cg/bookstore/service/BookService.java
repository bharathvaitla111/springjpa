package com.cg.bookstore.service;



public interface BookService {

	
	
}
