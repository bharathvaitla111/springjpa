package com.cg.bookstore.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.bookstore.beans.Customer_Information;
import com.cg.bookstore.dao.CustomerDao;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerDao;



	@Override
	public boolean createcustomer(Customer_Information customer) {
		
//		Customer_Information c = customerDao.findByemailId(customer.getEmailId());
		
		List<Customer_Information> cus = customerDao.findAll();
		
	
		
		
		boolean status = false;
		
		for(Customer_Information c : cus ) {
			
			if(c.getEmailId().equals(customer.getEmailId())) {
				
				status= true;
			}

		}
		
		if(status==true) {
			return false;
		}else {
			customerDao.save(customer);
			return true;
		}
	
	 }



	@Override
	public List<Customer_Information> getAllCustomers() {
		
		List<Customer_Information> cus = customerDao.findAll();
		
		return cus;
	}



	@Override
	public Customer_Information getCustomer_Information(int id) {
		// TODO Auto-generated method stub
		
		Customer_Information customer = customerDao.getOne(id);
		return customer;
	}



	@Override
	public void editCustomer(Customer_Information customer) {
	  customerDao.save(customer);	
	}



	@Override
	public void deleteCustomer(int id) {
		customerDao.deleteById(id);
		
	}
	
	
	}





