package com.cg.bookstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.cg.bookstore.beans.Customer_Information;
import com.cg.bookstore.service.CustomerService;

@Controller
public class CustomerController {

	

	@Autowired
	CustomerService customerService;
	
	
	@Autowired
	Customer_Information customer;
	
	
	ModelAndView modelView = new ModelAndView();
	
	
	@RequestMapping("/addcustomer")
	public ModelAndView addcustomer(HttpServletRequest request) {
		
		
		
		String email = request.getParameter("email");
		customer.setEmailId(email);
		
		String fullname = request.getParameter("fullname");
		customer.setCustomerName(fullname);
	
        String password = request.getParameter("password");
        String cpassword = request.getParameter("cpassword");
        
        if(password.equals(cpassword)) {
        	
		customer.setPassword(password);
		
        }else {
        	modelView.addObject("msg", "passwords are not correct!!");
			modelView.setViewName("customerRegister");
			return modelView;
        }
	

		String phoneno = request.getParameter("phoneno");
		customer.setPhoneNumber(phoneno);
		
		String address = request.getParameter("address");
		customer.setAddress(address);
		
		String city = request.getParameter("city");
		customer.setCity(city);
		
		String zipcode = request.getParameter("zipcode");
		customer.setZipCode(zipcode);
		
		String country = request.getParameter("country");
		customer.setCountry(country);
		
		
		
		boolean status = customerService.createcustomer(customer);
		
		if(status==true) {
			
			modelView.setViewName("redirect:/view/homee");
		}else {
			modelView.addObject("msg", "Customer with this Email already exists!!");
			modelView.setViewName("customerRegister");
		}
		
		
		return modelView;
	}
	
	

	@RequestMapping("/getcustomerlist")
	public ModelAndView viewAllCustomers(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		
		
		List<Customer_Information> customerList = customerService.getAllCustomers();
		
		session.setAttribute("list", customerList);
		
				modelView.setViewName("customersListPage");
		
		return modelView;
		
	}
	
	@RequestMapping("/edit")
	public ModelAndView edit(HttpServletRequest request, @RequestParam("customerid") int id) {
		
		HttpSession session = request.getSession();
		
		Customer_Information customer = customerService.getCustomer_Information(id);
		
		session.setAttribute("customer", customer);
		
		modelView.setViewName("customerEdit");
		
		return modelView;
		
	}
	
	
	@RequestMapping("/editcustomer")
	public ModelAndView editcustomer(HttpServletRequest request) {

		
		HttpSession session = request.getSession();
		
       Customer_Information customer = (Customer_Information)session.getAttribute("customer");
		
		String email = request.getParameter("email");
		customer.setEmailId(email);
		
		String fullname = request.getParameter("fullname");
		customer.setCustomerName(fullname);
	
        String password = request.getParameter("password");
		customer.setPassword(password);
		
      
		String phoneno = request.getParameter("phoneno");
		customer.setPhoneNumber(phoneno);
		
		String address = request.getParameter("address");
		customer.setAddress(address);
		
		String city = request.getParameter("city");
		customer.setCity(city);
		
		String zipcode = request.getParameter("zipcode");
		customer.setZipCode(zipcode);
		
		String country = request.getParameter("country");
		customer.setCountry(country);
		
		
		customerService.editCustomer(customer);
		
       List<Customer_Information> customerList = customerService.getAllCustomers();
		
		session.setAttribute("list", customerList);
		
		modelView.setViewName("sendredirect:/customersListPage");
		
		return modelView;
	}
	
	
	@RequestMapping("/delete")
	public ModelAndView deletecustomer(HttpServletRequest request,  @RequestParam("customerid") int id) {
		
		
		HttpSession session = request.getSession();
		
		
		customerService.deleteCustomer(id);
		
       List<Customer_Information> customerList = customerService.getAllCustomers();
		
		session.setAttribute("list", customerList);
		
		
		modelView.setViewName("sendredirect:/customersListPage");
		
		return modelView;
	}
	
}
