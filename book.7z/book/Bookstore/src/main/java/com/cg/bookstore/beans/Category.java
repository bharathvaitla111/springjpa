package com.cg.bookstore.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Category implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator="category1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="category1",sequenceName="category1",initialValue=1,allocationSize=1)
	private int categoryID;
	
	private String categoryName;

}
