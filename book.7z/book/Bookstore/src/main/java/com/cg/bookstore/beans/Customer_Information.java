package com.cg.bookstore.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Customer_Information implements Serializable{

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator="book1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="book1",sequenceName="book1",initialValue=1,allocationSize=1)
	private int customerId;
	
	private String customerName;
	
	private String emailId;
	
	private String password;
	
	private String phoneNumber;
	
	private String address;
	
	private String city;
	
	private String zipCode;
	
	private String country;

	private Date dateOfRegistration;
	
	public Customer_Information() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Customer_Information(int customerId, String customerName, String emailId, String password,
			String phoneNumber, String address, String city, String zipCode, String country, Date dateOfRegistration) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.password = password;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.city = city;
		this.zipCode = zipCode;
		this.country = country;
		this.dateOfRegistration = dateOfRegistration;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	

	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}



	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}



	@Override
	public String toString() {
		return "Customer_information [customerId=" + customerId + ", customerName=" + customerName + ", emailId="
				+ emailId + ", password=" + password + ", phoneNumber=" + phoneNumber + ", address=" + address
				+ ", city=" + city + ", zipCode=" + zipCode + ", country=" + country + ", dateOfRegistration="
				+ dateOfRegistration + "]";
	}



	
}
