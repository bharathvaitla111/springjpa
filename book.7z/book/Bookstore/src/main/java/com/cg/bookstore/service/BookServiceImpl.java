package com.cg.bookstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.bookstore.dao.BookDao;

@Service("bookService")
@Transactional
public class BookServiceImpl implements BookService{

	
	@Autowired
    BookDao bookDao;
	
}
