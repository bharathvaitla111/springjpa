package com.cg.bookstore.beans;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;



@Entity
@Component
public class Book_Information implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator="customer1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="customer1",sequenceName="customer1",initialValue=10,allocationSize=1)
	private int bookID;
	
	private String title;
	
	private String author;
	
	private String description;
	
	private String ISBNnumber;
	
	private Blob image;
	
	private float price;
	
	private Date publishedDate;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="categoryID")
	private Category category;

	public Book_Information() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book_Information(int bookID, String title, String author, String description, String iSBNnumber, Blob image,
			float price, Date publishedDate, Category category) {
		super();
		this.bookID = bookID;
		this.title = title;
		this.author = author;
		this.description = description;
		ISBNnumber = iSBNnumber;
		this.image = image;
		this.price = price;
		this.publishedDate = publishedDate;
		this.category = category;
	}

	public int getBookID() {
		return bookID;
	}

	public void setBookID(int bookID) {
		this.bookID = bookID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getISBNnumber() {
		return ISBNnumber;
	}

	public void setISBNnumber(String iSBNnumber) {
		ISBNnumber = iSBNnumber;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Book_Information [bookID=" + bookID + ", title=" + title + ", author=" + author + ", description="
				+ description + ", ISBNnumber=" + ISBNnumber + ", image=" + image + ", price=" + price
				+ ", publishedDate=" + publishedDate + ", category=" + category + "]";
	}
	
	
	
}
