package com.cg.bookstore.controller;
import com.cg.bookstore.beans.Customer_Information;
import com.cg.bookstore.service.*;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class BookStoreController {
	

	@Autowired
	BookService bookService;
	
	@Autowired
	CustomerService  customerService;

	@RequestMapping(value = "/")
	public ModelAndView home(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();

		HttpSession session = request.getSession();
		
		modelView.setViewName("homee");
		return modelView;
	
	}
	
	@RequestMapping(value = "/register")
	public ModelAndView register(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("customerRegister");
		
		return modelView;
	}
	
	
	

}
